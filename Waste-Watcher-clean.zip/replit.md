# Bounty — Food Waste Management System

A web platform connecting food donors (restaurants, caterers, households) with NGOs and people in need to reduce food waste and improve distribution efficiency.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/food-waste run dev` — run the frontend (port 22416)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite, Tailwind CSS, Framer Motion, Recharts, wouter
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — OpenAPI contract (source of truth)
- `lib/db/src/schema/` — Drizzle schema: `users.ts`, `food-listings.ts`, `requests.ts`
- `artifacts/api-server/src/routes/` — Express route handlers
- `artifacts/food-waste/src/` — React frontend

## Architecture decisions

- Contract-first: OpenAPI spec gates codegen, which gates the frontend hooks
- Three user roles: donor, ngo, admin
- Food listings have statuses: available → reserved → collected | expired
- Donation requests track status: pending → approved → collected | rejected
- Dashboard stats, category breakdown, and recent activity served via dedicated `/stats` endpoints

## Product

- **Dashboard**: live stats (food rescued kg, active listings, collections, members), recent activity feed, category breakdown chart
- **Food Listings**: browse, filter by status/category, post new listings, manage individual listing status
- **Requests**: view all donation requests, approve/reject/mark collected
- **Community**: directory of donors and NGOs, user registration and profiles

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- After schema changes: run `pnpm run typecheck:libs` before typechecking `api-server`
- After OpenAPI spec changes: always re-run codegen before using updated types

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
