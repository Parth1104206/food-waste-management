import { Router } from "express";
import { db, usersTable, foodListingsTable, donationRequestsTable } from "@workspace/db";
import { eq, count, sum } from "drizzle-orm";

const router = Router();

router.get("/stats", async (_req, res) => {
  const [listingCounts] = await db
    .select({ total: count() })
    .from(foodListingsTable);

  const [availableCount] = await db
    .select({ total: count() })
    .from(foodListingsTable)
    .where(eq(foodListingsTable.status, "available"));

  const [collectedCount] = await db
    .select({ total: count() })
    .from(donationRequestsTable)
    .where(eq(donationRequestsTable.status, "collected"));

  const [pendingCount] = await db
    .select({ total: count() })
    .from(donationRequestsTable)
    .where(eq(donationRequestsTable.status, "pending"));

  const [donorCount] = await db
    .select({ total: count() })
    .from(usersTable)
    .where(eq(usersTable.role, "donor"));

  const [ngoCount] = await db
    .select({ total: count() })
    .from(usersTable)
    .where(eq(usersTable.role, "ngo"));

  const [totalFood] = await db
    .select({ total: sum(foodListingsTable.quantity) })
    .from(foodListingsTable)
    .where(eq(foodListingsTable.status, "collected"));

  res.json({
    totalListings: Number(listingCounts?.total ?? 0),
    availableListings: Number(availableCount?.total ?? 0),
    collectedDonations: Number(collectedCount?.total ?? 0),
    pendingRequests: Number(pendingCount?.total ?? 0),
    totalDonors: Number(donorCount?.total ?? 0),
    totalNgos: Number(ngoCount?.total ?? 0),
    totalFoodKg: Number(totalFood?.total ?? 0),
  });
});

router.get("/stats/category-breakdown", async (_req, res) => {
  const rows = await db
    .select({ category: foodListingsTable.category, total: count() })
    .from(foodListingsTable)
    .groupBy(foodListingsTable.category);

  res.json(rows.map((r) => ({ category: r.category, count: Number(r.total) })));
});

router.get("/stats/recent-activity", async (_req, res) => {
  const listings = await db
    .select()
    .from(foodListingsTable)
    .orderBy(foodListingsTable.createdAt)
    .limit(5);

  const requests = await db
    .select({
      request: donationRequestsTable,
      listingTitle: foodListingsTable.title,
    })
    .from(donationRequestsTable)
    .leftJoin(foodListingsTable, eq(donationRequestsTable.listingId, foodListingsTable.id))
    .orderBy(donationRequestsTable.createdAt)
    .limit(5);

  const listingItems = listings.map((l) => ({
    id: l.id,
    type: "listing" as const,
    title: l.title,
    description: `${l.quantity} ${l.unit} of ${l.category} available`,
    status: l.status,
    createdAt: l.createdAt.toISOString(),
  }));

  const requestItems = requests.map((r) => ({
    id: r.request.id,
    type: "request" as const,
    title: r.listingTitle ?? "Food item",
    description: `Request to collect — status: ${r.request.status}`,
    status: r.request.status,
    createdAt: r.request.createdAt.toISOString(),
  }));

  const combined = [...listingItems, ...requestItems]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 10);

  res.json(combined);
});

export default router;
