import { Router } from "express";
import { db, donationRequestsTable, usersTable, foodListingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateRequestBody,
  UpdateRequestBody,
  ListRequestsQueryParams,
} from "@workspace/api-zod";

const router = Router();

function formatRequest(
  req_row: typeof donationRequestsTable.$inferSelect,
  listingTitle: string | null,
  requesterName: string | null,
  requesterOrganization: string | null
) {
  return {
    id: req_row.id,
    listingId: req_row.listingId,
    listingTitle,
    requesterId: req_row.requesterId,
    requesterName,
    requesterOrganization,
    status: req_row.status,
    message: req_row.message ?? null,
    createdAt: req_row.createdAt.toISOString(),
    updatedAt: req_row.updatedAt.toISOString(),
  };
}

router.get("/requests", async (req, res) => {
  const parsed = ListRequestsQueryParams.safeParse(req.query);
  const filters = parsed.success ? parsed.data : {};

  const rows = await db
    .select({
      request: donationRequestsTable,
      listingTitle: foodListingsTable.title,
      requesterName: usersTable.name,
      requesterOrganization: usersTable.organization,
    })
    .from(donationRequestsTable)
    .leftJoin(foodListingsTable, eq(donationRequestsTable.listingId, foodListingsTable.id))
    .leftJoin(usersTable, eq(donationRequestsTable.requesterId, usersTable.id));

  let result = rows;
  if (filters.status) {
    result = result.filter((r) => r.request.status === filters.status);
  }
  if (filters.requesterId !== undefined) {
    const rid = Number(filters.requesterId);
    result = result.filter((r) => r.request.requesterId === rid);
  }
  if (filters.listingId !== undefined) {
    const lid = Number(filters.listingId);
    result = result.filter((r) => r.request.listingId === lid);
  }

  res.json(
    result.map((r) =>
      formatRequest(r.request, r.listingTitle ?? null, r.requesterName ?? null, r.requesterOrganization ?? null)
    )
  );
});

router.post("/requests", async (req, res) => {
  const parsed = CreateRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { listingId, requesterId, message } = parsed.data;

  const [request] = await db
    .insert(donationRequestsTable)
    .values({ listingId, requesterId, message })
    .returning();

  const [listing] = await db.select({ title: foodListingsTable.title }).from(foodListingsTable).where(eq(foodListingsTable.id, listingId));
  const [requester] = await db.select({ name: usersTable.name, organization: usersTable.organization }).from(usersTable).where(eq(usersTable.id, requesterId));

  res.status(201).json(
    formatRequest(request, listing?.title ?? null, requester?.name ?? null, requester?.organization ?? null)
  );
});

router.get("/requests/:id", async (req, res) => {
  const id = parseInt(req.params.id, 10);

  const [row] = await db
    .select({
      request: donationRequestsTable,
      listingTitle: foodListingsTable.title,
      requesterName: usersTable.name,
      requesterOrganization: usersTable.organization,
    })
    .from(donationRequestsTable)
    .leftJoin(foodListingsTable, eq(donationRequestsTable.listingId, foodListingsTable.id))
    .leftJoin(usersTable, eq(donationRequestsTable.requesterId, usersTable.id))
    .where(eq(donationRequestsTable.id, id));

  if (!row) {
    res.status(404).json({ error: "Request not found" });
    return;
  }

  res.json(formatRequest(row.request, row.listingTitle ?? null, row.requesterName ?? null, row.requesterOrganization ?? null));
});

router.patch("/requests/:id", async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const parsed = UpdateRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Partial<typeof donationRequestsTable.$inferInsert> = {
    ...parsed.data,
    updatedAt: new Date(),
  };

  const [request] = await db
    .update(donationRequestsTable)
    .set(updateData)
    .where(eq(donationRequestsTable.id, id))
    .returning();

  if (!request) {
    res.status(404).json({ error: "Request not found" });
    return;
  }

  const [listing] = await db.select({ title: foodListingsTable.title }).from(foodListingsTable).where(eq(foodListingsTable.id, request.listingId));
  const [requester] = await db.select({ name: usersTable.name, organization: usersTable.organization }).from(usersTable).where(eq(usersTable.id, request.requesterId));

  res.json(formatRequest(request, listing?.title ?? null, requester?.name ?? null, requester?.organization ?? null));
});

export default router;
