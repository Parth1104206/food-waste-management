import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { CreateUserBody, UpdateUserBody, ListUsersQueryParams } from "@workspace/api-zod";

const router = Router();

router.get("/users", async (req, res) => {
  const parsed = ListUsersQueryParams.safeParse(req.query);
  const filters = parsed.success ? parsed.data : {};

  let query = db.select().from(usersTable);
  const rows = await query;

  const result = filters.role
    ? rows.filter((u) => u.role === filters.role)
    : rows;

  res.json(
    result.map((u) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      phone: u.phone ?? null,
      address: u.address ?? null,
      organization: u.organization ?? null,
      createdAt: u.createdAt.toISOString(),
    }))
  );
});

router.post("/users", async (req, res) => {
  const parsed = CreateUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { name, email, role, phone, address, organization } = parsed.data;

  const [user] = await db
    .insert(usersTable)
    .values({ name, email, role: role as "donor" | "ngo" | "admin", phone, address, organization })
    .returning();

  res.status(201).json({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    phone: user.phone ?? null,
    address: user.address ?? null,
    organization: user.organization ?? null,
    createdAt: user.createdAt.toISOString(),
  });
});

router.get("/users/:id", async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    phone: user.phone ?? null,
    address: user.address ?? null,
    organization: user.organization ?? null,
    createdAt: user.createdAt.toISOString(),
  });
});

router.patch("/users/:id", async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const parsed = UpdateUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [user] = await db
    .update(usersTable)
    .set(parsed.data)
    .where(eq(usersTable.id, id))
    .returning();

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    phone: user.phone ?? null,
    address: user.address ?? null,
    organization: user.organization ?? null,
    createdAt: user.createdAt.toISOString(),
  });
});

export default router;
