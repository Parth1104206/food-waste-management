import { Router, type IRouter } from "express";
import healthRouter from "./health";
import usersRouter from "./users";
import foodListingsRouter from "./food-listings";
import requestsRouter from "./requests";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use(usersRouter);
router.use(foodListingsRouter);
router.use(requestsRouter);
router.use(statsRouter);

export default router;
