import { Router } from "express";
import { db, foodListingsTable, usersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  CreateFoodListingBody,
  UpdateFoodListingBody,
  ListFoodListingsQueryParams,
} from "@workspace/api-zod";

const router = Router();

function formatListing(listing: typeof foodListingsTable.$inferSelect, donorName: string | null) {
  return {
    id: listing.id,
    donorId: listing.donorId,
    donorName,
    title: listing.title,
    description: listing.description ?? null,
    category: listing.category,
    quantity: listing.quantity,
    unit: listing.unit,
    status: listing.status,
    location: listing.location ?? null,
    expiresAt: listing.expiresAt.toISOString(),
    createdAt: listing.createdAt.toISOString(),
  };
}

router.get("/food-listings", async (req, res) => {
  const parsed = ListFoodListingsQueryParams.safeParse(req.query);
  const filters = parsed.success ? parsed.data : {};

  const rows = await db
    .select({ listing: foodListingsTable, donorName: usersTable.name })
    .from(foodListingsTable)
    .leftJoin(usersTable, eq(foodListingsTable.donorId, usersTable.id));

  let result = rows;
  if (filters.status) {
    result = result.filter((r) => r.listing.status === filters.status);
  }
  if (filters.category) {
    result = result.filter((r) => r.listing.category === filters.category);
  }
  if (filters.donorId !== undefined) {
    const donorId = Number(filters.donorId);
    result = result.filter((r) => r.listing.donorId === donorId);
  }

  res.json(result.map((r) => formatListing(r.listing, r.donorName ?? null)));
});

router.post("/food-listings", async (req, res) => {
  const parsed = CreateFoodListingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { donorId, title, description, category, quantity, unit, location, expiresAt } = parsed.data;

  const [listing] = await db
    .insert(foodListingsTable)
    .values({
      donorId,
      title,
      description,
      category,
      quantity,
      unit,
      location,
      expiresAt: new Date(expiresAt),
    })
    .returning();

  const [donor] = await db.select({ name: usersTable.name }).from(usersTable).where(eq(usersTable.id, donorId));

  res.status(201).json(formatListing(listing, donor?.name ?? null));
});

router.get("/food-listings/:id", async (req, res) => {
  const id = parseInt(req.params.id, 10);

  const [row] = await db
    .select({ listing: foodListingsTable, donorName: usersTable.name })
    .from(foodListingsTable)
    .leftJoin(usersTable, eq(foodListingsTable.donorId, usersTable.id))
    .where(eq(foodListingsTable.id, id));

  if (!row) {
    res.status(404).json({ error: "Food listing not found" });
    return;
  }

  res.json(formatListing(row.listing, row.donorName ?? null));
});

router.patch("/food-listings/:id", async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const parsed = UpdateFoodListingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Partial<typeof foodListingsTable.$inferInsert> = { ...parsed.data };
  if (parsed.data.expiresAt) {
    updateData.expiresAt = new Date(parsed.data.expiresAt);
  }

  const [listing] = await db
    .update(foodListingsTable)
    .set(updateData)
    .where(eq(foodListingsTable.id, id))
    .returning();

  if (!listing) {
    res.status(404).json({ error: "Food listing not found" });
    return;
  }

  const [donor] = await db.select({ name: usersTable.name }).from(usersTable).where(eq(usersTable.id, listing.donorId));

  res.json(formatListing(listing, donor?.name ?? null));
});

router.delete("/food-listings/:id", async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const deleted = await db.delete(foodListingsTable).where(eq(foodListingsTable.id, id)).returning();

  if (!deleted.length) {
    res.status(404).json({ error: "Food listing not found" });
    return;
  }

  res.status(204).send();
});

export default router;
