import { useParams, Link } from "wouter";
import { useGetFoodListing, useListRequests, useUpdateFoodListing, useUpdateRequest, useCreateRequest, getGetFoodListingQueryKey, getListRequestsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Apple, MapPin, Clock, ArrowLeft, Building2, UserCircle, CheckCircle, XCircle } from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function FoodListingDetail() {
  const params = useParams();
  const id = parseInt(params.id || "0", 10);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: listing, isLoading: listingLoading } = useGetFoodListing(id, { query: { enabled: !!id } });
  const { data: requests, isLoading: requestsLoading } = useListRequests({ listingId: id }, { query: { enabled: !!id } });
  
  const updateListing = useUpdateFoodListing();
  const updateRequest = useUpdateRequest();
  const createRequest = useCreateRequest();

  const handleStatusChange = (status: "available" | "reserved" | "collected" | "expired") => {
    updateListing.mutate(
      { id, data: { status } },
      {
        onSuccess: (data) => {
          toast({ title: "Status updated", description: `Listing is now marked as ${status}.` });
          queryClient.setQueryData(getGetFoodListingQueryKey(id), data);
          queryClient.invalidateQueries({ queryKey: getListRequestsQueryKey({ listingId: id }) });
        }
      }
    );
  };

  const handleRequestStatus = (reqId: number, status: "pending" | "approved" | "rejected" | "collected") => {
    updateRequest.mutate(
      { id: reqId, data: { status } },
      {
        onSuccess: () => {
          toast({ title: "Request updated", description: `Request has been ${status}.` });
          queryClient.invalidateQueries({ queryKey: getListRequestsQueryKey({ listingId: id }) });
          
          // Auto-update listing status if a request is approved or collected
          if (status === "approved") {
            handleStatusChange("reserved");
          } else if (status === "collected") {
            handleStatusChange("collected");
          }
        }
      }
    );
  };

  const handleMockRequest = () => {
    // In a real app, this would use the current logged-in user
    createRequest.mutate(
      { data: { listingId: id, requesterId: 2, message: "We can pick this up immediately." } },
      {
        onSuccess: () => {
          toast({ title: "Request sent", description: "The donor will be notified of your request." });
          queryClient.invalidateQueries({ queryKey: getListRequestsQueryKey({ listingId: id }) });
        }
      }
    );
  };

  if (listingLoading) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <Skeleton className="h-8 w-32" />
        <Card>
          <Skeleton className="h-[300px] w-full" />
        </Card>
      </div>
    );
  }

  if (!listing) return <div className="p-8 text-center text-muted-foreground">Listing not found</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <Link href="/food-listings">
          <Button variant="ghost" size="sm" className="mb-2 -ml-3 text-muted-foreground">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to listings
          </Button>
        </Link>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h1 className="text-3xl font-serif font-bold text-foreground">{listing.title}</h1>
          <StatusBadge status={listing.status} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <Card className="shadow-sm overflow-hidden">
            <div className="h-48 bg-muted flex items-center justify-center relative">
              <Apple className="h-20 w-20 text-muted-foreground/30" />
              <div className="absolute bottom-4 left-4">
                <span className="inline-flex items-center rounded-md bg-background/80 backdrop-blur px-3 py-1 text-sm font-medium text-foreground">
                  {listing.category}
                </span>
              </div>
            </div>
            <CardContent className="p-6">
              <div className="flex flex-wrap gap-4 mb-6 pb-6 border-b">
                <div className="flex items-center gap-2 bg-secondary/10 text-secondary px-3 py-1.5 rounded-md font-medium">
                  <Apple className="h-4 w-4" />
                  <span>{listing.quantity} {listing.unit}</span>
                </div>
                {listing.location && (
                  <div className="flex items-center gap-2 text-muted-foreground bg-muted px-3 py-1.5 rounded-md">
                    <MapPin className="h-4 w-4" />
                    <span>{listing.location}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-muted-foreground bg-muted px-3 py-1.5 rounded-md">
                  <Clock className="h-4 w-4" />
                  <span>Expires {format(new Date(listing.expiresAt), "MMM d, yyyy")}</span>
                </div>
              </div>

              <div>
                <h3 className="font-serif font-medium text-lg mb-2">Description</h3>
                <p className="text-muted-foreground whitespace-pre-wrap leading-relaxed">
                  {listing.description || "No description provided."}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="font-serif">Requests for this listing</CardTitle>
            </CardHeader>
            <CardContent>
              {requestsLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                </div>
              ) : requests && requests.length > 0 ? (
                <div className="space-y-4">
                  {requests.map(req => (
                    <div key={req.id} className="border rounded-lg p-4 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{req.requesterName}</span>
                          <span className="text-muted-foreground text-sm">({req.requesterOrganization})</span>
                          <StatusBadge status={req.status} />
                        </div>
                        {req.message && <p className="text-sm text-muted-foreground italic">"{req.message}"</p>}
                        <p className="text-xs text-muted-foreground">Requested {formatDistanceToNow(new Date(req.createdAt), { addSuffix: true })}</p>
                      </div>
                      
                      <div className="flex gap-2 w-full sm:w-auto">
                        {req.status === 'pending' && (
                          <>
                            <Button size="sm" variant="outline" className="flex-1 sm:flex-none border-destructive/30 text-destructive hover:bg-destructive/10" onClick={() => handleRequestStatus(req.id, "rejected")}>
                              <XCircle className="h-4 w-4 mr-1" /> Reject
                            </Button>
                            <Button size="sm" className="flex-1 sm:flex-none bg-primary hover:bg-primary/90" onClick={() => handleRequestStatus(req.id, "approved")}>
                              <CheckCircle className="h-4 w-4 mr-1" /> Approve
                            </Button>
                          </>
                        )}
                        {req.status === 'approved' && (
                          <Button size="sm" variant="outline" className="w-full sm:w-auto border-chart-3/30 text-chart-3 hover:bg-chart-3/10" onClick={() => handleRequestStatus(req.id, "collected")}>
                            Mark Collected
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground border border-dashed rounded-lg bg-muted/30">
                  <p>No requests yet.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="font-serif text-lg">Donor Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                  <Building2 className="h-6 w-6" />
                </div>
                <div>
                  <p className="font-medium">{listing.donorName}</p>
                  <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                    <UserCircle className="h-3 w-3" />
                    Donor
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="font-serif text-lg">Manage Listing</CardTitle>
              <CardDescription>Update the status of this food donation.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {listing.status === 'available' && (
                <>
                  <Button variant="outline" className="w-full justify-start border-chart-4/30 text-chart-4 hover:bg-chart-4/10" onClick={() => handleStatusChange('reserved')}>
                    Mark as Reserved
                  </Button>
                  <Button variant="outline" className="w-full justify-start border-destructive/30 text-destructive hover:bg-destructive/10" onClick={() => handleStatusChange('expired')}>
                    Mark as Expired
                  </Button>
                  
                  {/* Action for non-donors (demo purpose) */}
                  <div className="pt-4 mt-4 border-t">
                    <Button className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground" onClick={handleMockRequest}>
                      Request This Food
                    </Button>
                  </div>
                </>
              )}
              {listing.status === 'reserved' && (
                <>
                  <Button variant="outline" className="w-full justify-start border-primary/30 text-primary hover:bg-primary/10" onClick={() => handleStatusChange('available')}>
                    Make Available Again
                  </Button>
                  <Button variant="outline" className="w-full justify-start border-chart-3/30 text-chart-3 hover:bg-chart-3/10" onClick={() => handleStatusChange('collected')}>
                    Mark as Collected
                  </Button>
                </>
              )}
              {(listing.status === 'collected' || listing.status === 'expired') && (
                <p className="text-sm text-muted-foreground text-center py-2">
                  This listing is closed and cannot be updated.
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
