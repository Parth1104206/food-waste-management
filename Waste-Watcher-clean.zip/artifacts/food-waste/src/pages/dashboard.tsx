import { useGetDashboardStats, useGetRecentActivity, useGetCategoryBreakdown } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Apple, Scale, Users, UtensilsCrossed, ArrowRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { StatusBadge } from "@/components/ui/status-badge";
import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats();
  const { data: activities, isLoading: activityLoading } = useGetRecentActivity();
  const { data: categories, isLoading: categoriesLoading } = useGetCategoryBreakdown();

  const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-serif font-bold text-foreground">Community Impact</h1>
        <p className="text-muted-foreground mt-2 text-lg">Here's the difference we're making together.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statsLoading ? (
          Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-[120px] rounded-xl" />)
        ) : stats ? (
          <>
            <StatCard 
              title="Food Rescued" 
              value={`${stats.totalFoodKg} kg`} 
              icon={Scale} 
              color="text-primary" 
              bg="bg-primary/10" 
            />
            <StatCard 
              title="Active Listings" 
              value={stats.availableListings.toString()} 
              icon={Apple} 
              color="text-chart-2" 
              bg="bg-chart-2/10" 
            />
            <StatCard 
              title="Successful Collections" 
              value={stats.collectedDonations.toString()} 
              icon={UtensilsCrossed} 
              color="text-chart-3" 
              bg="bg-chart-3/10" 
            />
            <StatCard 
              title="Community Members" 
              value={(stats.totalDonors + stats.totalNgos).toString()} 
              icon={Users} 
              color="text-chart-4" 
              bg="bg-chart-4/10" 
            />
          </>
        ) : null}
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="font-serif text-xl">Recent Activity</CardTitle>
              <CardDescription>The latest updates from the community.</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            {activityLoading ? (
              <div className="space-y-4 mt-4">
                {Array(5).fill(0).map((_, i) => (
                  <div key={i} className="flex items-center gap-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-4 w-1/3" />
                      <Skeleton className="h-3 w-1/4" />
                    </div>
                  </div>
                ))}
              </div>
            ) : activities && activities.length > 0 ? (
              <div className="mt-4 space-y-6">
                {activities.map((item) => (
                  <div key={item.id} className="flex items-start gap-4">
                    <div className={`mt-1 flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
                      item.type === 'listing' ? 'bg-primary/10 text-primary' : 'bg-chart-2/10 text-chart-2'
                    }`}>
                      {item.type === 'listing' ? <Apple className="h-5 w-5" /> : <UtensilsCrossed className="h-5 w-5" />}
                    </div>
                    <div className="flex-1 space-y-1">
                      <p className="text-sm font-medium leading-none">
                        {item.title}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {item.description}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground pt-1">
                        <span>{formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}</span>
                        {item.status && (
                          <>
                            <span>•</span>
                            <StatusBadge status={item.status} />
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="rounded-full bg-muted p-3 mb-3">
                  <Apple className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="font-medium text-lg">No recent activity</h3>
                <p className="text-muted-foreground text-sm max-w-sm">When food is posted or requested, it will show up here.</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="font-serif text-xl">Categories</CardTitle>
            <CardDescription>What's being shared most.</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px] flex items-center justify-center">
            {categoriesLoading ? (
              <Skeleton className="h-[200px] w-[200px] rounded-full" />
            ) : categories && categories.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categories}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="count"
                    nameKey="category"
                  >
                    {categories.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center text-muted-foreground">No data available</div>
            )}
          </CardContent>
          {categories && categories.length > 0 && (
            <div className="px-6 pb-6 space-y-2">
              {categories.map((category, index) => (
                <div key={category.category} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                    <span className="capitalize">{category.category}</span>
                  </div>
                  <span className="font-medium">{category.count}</span>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color, bg }: any) {
  return (
    <Card className="shadow-sm border-border/50">
      <CardContent className="p-6">
        <div className="flex items-center justify-between space-y-0 pb-2">
          <p className="text-sm font-medium text-muted-foreground">
            {title}
          </p>
          <div className={`h-10 w-10 rounded-full flex items-center justify-center ${bg} ${color}`}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
        <div className="flex items-baseline space-x-3">
          <h2 className="text-3xl font-serif font-bold text-foreground">
            {value}
          </h2>
        </div>
      </CardContent>
    </Card>
  );
}
