import { useListUsers } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Users as UsersIcon, PlusCircle, Building2, Phone, Mail, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Users() {
  const { data: users, isLoading } = useListUsers();

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-serif font-bold text-foreground">Community</h1>
          <p className="text-muted-foreground mt-2 text-lg">Donors and NGOs making a difference.</p>
        </div>
        <Link href="/users/new">
          <Button className="gap-2 shadow-sm">
            <PlusCircle className="h-4 w-4" />
            Add Member
          </Button>
        </Link>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {isLoading ? (
          Array(6).fill(0).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <CardHeader className="space-y-2 pb-2">
                <div className="flex items-center gap-4">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-4 w-20" />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 mt-4">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-4/5" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : users && users.length > 0 ? (
          users.map((user) => (
            <Link key={user.id} href={`/users/${user.id}`}>
              <Card className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow h-full flex flex-col">
                <CardHeader className="pb-4 border-b border-border/50 bg-muted/20">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`h-12 w-12 rounded-full flex items-center justify-center shrink-0 ${
                        user.role === 'donor' ? 'bg-primary/10 text-primary' : 
                        user.role === 'ngo' ? 'bg-chart-2/10 text-chart-2' : 
                        'bg-muted text-muted-foreground'
                      }`}>
                        {user.role === 'donor' ? <Building2 className="h-6 w-6" /> : <UsersIcon className="h-6 w-6" />}
                      </div>
                      <div>
                        <CardTitle className="font-serif text-lg">{user.name}</CardTitle>
                        <p className="text-sm text-muted-foreground line-clamp-1">{user.organization || "Independent"}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="capitalize">
                      {user.role}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-5 flex-1 space-y-3">
                  <div className="flex items-center gap-2.5 text-sm text-muted-foreground">
                    <Mail className="h-4 w-4 shrink-0 text-foreground/40" />
                    <span className="truncate">{user.email}</span>
                  </div>
                  {user.phone && (
                    <div className="flex items-center gap-2.5 text-sm text-muted-foreground">
                      <Phone className="h-4 w-4 shrink-0 text-foreground/40" />
                      <span>{user.phone}</span>
                    </div>
                  )}
                  {user.address && (
                    <div className="flex items-start gap-2.5 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4 shrink-0 text-foreground/40 mt-0.5" />
                      <span className="line-clamp-2">{user.address}</span>
                    </div>
                  )}
                </CardContent>
              </Card>
            </Link>
          ))
        ) : (
          <div className="col-span-full flex flex-col items-center justify-center py-20 text-center">
            <div className="rounded-full bg-muted p-4 mb-4">
              <UsersIcon className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="font-serif text-xl font-medium text-foreground mb-2">No community members yet</h3>
            <p className="text-muted-foreground max-w-sm mb-6">Start building your network of donors and NGOs.</p>
            <Link href="/users/new">
              <Button>Add the first member</Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
