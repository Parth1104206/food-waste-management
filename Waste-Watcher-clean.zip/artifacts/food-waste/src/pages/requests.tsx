import { useListRequests, useUpdateRequest, getListRequestsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";
import { UtensilsCrossed, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";

export default function Requests() {
  const [filter, setFilter] = useState<string>("all");
  const { data: requests, isLoading } = useListRequests(
    filter !== "all" ? { status: filter as any } : {}
  );
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const updateRequest = useUpdateRequest();

  const handleStatusChange = (id: number, status: "pending" | "approved" | "rejected" | "collected") => {
    updateRequest.mutate(
      { id, data: { status } },
      {
        onSuccess: () => {
          toast({ title: "Status updated", description: `Request marked as ${status}.` });
          queryClient.invalidateQueries({ queryKey: getListRequestsQueryKey() });
        }
      }
    );
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-serif font-bold text-foreground">Donation Requests</h1>
        <p className="text-muted-foreground mt-2 text-lg">Manage requests for food listings.</p>
      </div>

      <Tabs defaultValue="all" value={filter} onValueChange={setFilter}>
        <TabsList className="mb-6">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="approved">Approved</TabsTrigger>
          <TabsTrigger value="collected">Collected</TabsTrigger>
        </TabsList>

        <div className="space-y-4">
          {isLoading ? (
            Array(4).fill(0).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6 flex items-center justify-between">
                  <div className="space-y-2">
                    <Skeleton className="h-5 w-48" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                  <Skeleton className="h-8 w-24" />
                </CardContent>
              </Card>
            ))
          ) : requests && requests.length > 0 ? (
            requests.map((request) => (
              <Card key={request.id} className="shadow-sm hover:shadow transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-4 justify-between md:items-center">
                    <div className="flex items-start gap-4">
                      <div className="mt-1 h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                        <UtensilsCrossed className="h-5 w-5" />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Link href={`/food-listings/${request.listingId}`} className="font-medium hover:text-primary transition-colors">
                            {request.listingTitle || `Listing #${request.listingId}`}
                          </Link>
                          <StatusBadge status={request.status} />
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Requested by <span className="font-medium text-foreground">{request.requesterName}</span> ({request.requesterOrganization})
                        </p>
                        {request.message && (
                          <p className="text-sm italic text-muted-foreground pt-1">
                            "{request.message}"
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground pt-1">
                          {formatDistanceToNow(new Date(request.createdAt), { addSuffix: true })}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Link href={`/food-listings/${request.listingId}`}>
                        <Button variant="outline" size="sm">
                          View Listing
                        </Button>
                      </Link>
                      {request.status === 'pending' && (
                        <>
                          <Button size="sm" variant="outline" className="border-destructive/30 text-destructive hover:bg-destructive/10" onClick={() => handleStatusChange(request.id, "rejected")}>
                            Reject
                          </Button>
                          <Button size="sm" className="bg-primary hover:bg-primary/90" onClick={() => handleStatusChange(request.id, "approved")}>
                            Approve
                          </Button>
                        </>
                      )}
                      {request.status === 'approved' && (
                        <Button size="sm" className="bg-chart-3 hover:bg-chart-3/90 text-white" onClick={() => handleStatusChange(request.id, "collected")}>
                          Mark Collected
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-center bg-card rounded-xl border border-dashed">
              <div className="rounded-full bg-muted p-4 mb-4">
                <UtensilsCrossed className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="font-serif text-xl font-medium text-foreground mb-2">No requests found</h3>
              <p className="text-muted-foreground max-w-sm">
                {filter === 'all' ? "There are no requests in the system yet." : `No requests match the "${filter}" status.`}
              </p>
            </div>
          )}
        </div>
      </Tabs>
    </div>
  );
}
