import { useListFoodListings } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Apple, MapPin, Clock, PlusCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function FoodListings() {
  const { data: listings, isLoading } = useListFoodListings();

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-serif font-bold text-foreground">Food Board</h1>
          <p className="text-muted-foreground mt-2 text-lg">Available surplus food in your community.</p>
        </div>
        <Link href="/food-listings/new">
          <Button className="gap-2 shadow-sm">
            <PlusCircle className="h-4 w-4" />
            Share Food
          </Button>
        </Link>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {isLoading ? (
          Array(6).fill(0).map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="h-48 w-full rounded-none" />
              <CardHeader className="space-y-2">
                <Skeleton className="h-6 w-2/3" />
                <Skeleton className="h-4 w-1/3" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-4/5" />
              </CardContent>
            </Card>
          ))
        ) : listings && listings.length > 0 ? (
          listings.map((listing) => (
            <Card key={listing.id} className="overflow-hidden flex flex-col group hover:shadow-md transition-all duration-300">
              <div className="h-48 bg-muted flex items-center justify-center relative overflow-hidden group-hover:bg-muted/80 transition-colors">
                <Apple className="h-16 w-16 text-muted-foreground/30" />
                <div className="absolute top-4 right-4">
                  <StatusBadge status={listing.status} />
                </div>
                <div className="absolute bottom-4 left-4">
                  <span className="inline-flex items-center rounded-md bg-background/80 backdrop-blur px-2 py-1 text-xs font-medium text-foreground">
                    {listing.category}
                  </span>
                </div>
              </div>
              <CardHeader className="pb-3">
                <CardTitle className="font-serif text-xl line-clamp-1 group-hover:text-primary transition-colors">
                  <Link href={`/food-listings/${listing.id}`}>
                    {listing.title}
                  </Link>
                </CardTitle>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                  <span>{listing.donorName}</span>
                </div>
              </CardHeader>
              <CardContent className="pb-4 flex-1">
                <div className="flex flex-wrap gap-y-2 gap-x-4 text-sm mb-4">
                  <div className="flex items-center gap-1.5 text-foreground font-medium bg-secondary/10 text-secondary px-2.5 py-1 rounded-md">
                    <Apple className="h-3.5 w-3.5" />
                    <span>{listing.quantity} {listing.unit}</span>
                  </div>
                  {listing.location && (
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <MapPin className="h-3.5 w-3.5" />
                      <span className="line-clamp-1 max-w-[120px]">{listing.location}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <Clock className="h-3.5 w-3.5" />
                    <span>Expires {formatDistanceToNow(new Date(listing.expiresAt), { addSuffix: true })}</span>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {listing.description || "No description provided."}
                </p>
              </CardContent>
              <CardFooter className="pt-0 border-t p-4 mt-auto">
                <Link href={`/food-listings/${listing.id}`} className="w-full">
                  <Button variant="secondary" className="w-full bg-secondary/10 hover:bg-secondary/20 text-secondary-foreground shadow-none">
                    View Details
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))
        ) : (
          <div className="col-span-full flex flex-col items-center justify-center py-20 text-center">
            <div className="rounded-full bg-muted p-4 mb-4">
              <Apple className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="font-serif text-xl font-medium text-foreground mb-2">No food listings yet</h3>
            <p className="text-muted-foreground max-w-sm mb-6">There are currently no active food listings in the community.</p>
            <Link href="/food-listings/new">
              <Button>Post the first one</Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
