import { useParams, Link } from "wouter";
import { useGetUser, useUpdateUser, getGetUserQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Building2, Users as UsersIcon, ArrowLeft, Mail, Phone, MapPin, CalendarDays, Edit } from "lucide-react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function UserDetail() {
  const params = useParams();
  const id = parseInt(params.id || "0", 10);

  const { data: user, isLoading } = useGetUser(id, { query: { enabled: !!id } });

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto space-y-6">
        <Skeleton className="h-8 w-32" />
        <Card>
          <Skeleton className="h-[200px] w-full" />
        </Card>
      </div>
    );
  }

  if (!user) return <div className="p-8 text-center text-muted-foreground">Member not found</div>;

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <Link href="/users">
          <Button variant="ghost" size="sm" className="mb-2 -ml-3 text-muted-foreground">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to community
          </Button>
        </Link>
      </div>

      <Card className="shadow-sm overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-primary/20 to-secondary/20 relative"></div>
        <CardContent className="px-8 pb-8">
          <div className="flex flex-col sm:flex-row justify-between gap-6 -mt-12 sm:-mt-16 mb-6">
            <div className="h-24 w-24 sm:h-32 sm:w-32 rounded-full border-4 border-background bg-card flex items-center justify-center shadow-sm shrink-0">
              {user.role === 'donor' ? (
                <Building2 className="h-10 w-10 sm:h-14 sm:w-14 text-primary" />
              ) : (
                <UsersIcon className="h-10 w-10 sm:h-14 sm:w-14 text-chart-2" />
              )}
            </div>
            <div className="sm:mt-20 flex gap-2">
              <Badge variant="secondary" className="capitalize px-3 py-1 h-fit text-sm">
                {user.role}
              </Badge>
              {/* Future feature: Edit Profile */}
              <Button variant="outline" size="sm" disabled>
                <Edit className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
            </div>
          </div>

          <div className="space-y-1 mb-8">
            <h1 className="text-3xl font-serif font-bold text-foreground">{user.name}</h1>
            {user.organization && (
              <p className="text-xl text-muted-foreground">{user.organization}</p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="font-medium border-b pb-2">Contact Info</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Mail className="h-5 w-5 text-foreground/40 shrink-0" />
                  <span className="text-foreground">{user.email}</span>
                </div>
                {user.phone && (
                  <div className="flex items-center gap-3 text-muted-foreground">
                    <Phone className="h-5 w-5 text-foreground/40 shrink-0" />
                    <span className="text-foreground">{user.phone}</span>
                  </div>
                )}
                {user.address && (
                  <div className="flex items-start gap-3 text-muted-foreground">
                    <MapPin className="h-5 w-5 text-foreground/40 shrink-0 mt-0.5" />
                    <span className="text-foreground">{user.address}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="font-medium border-b pb-2">Account Info</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-muted-foreground">
                  <CalendarDays className="h-5 w-5 text-foreground/40 shrink-0" />
                  <span>Joined {format(new Date(user.createdAt), "MMMM d, yyyy")}</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
