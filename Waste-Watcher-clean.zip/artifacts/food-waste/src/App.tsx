import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import Dashboard from "@/pages/dashboard";
import FoodListings from "@/pages/food-listings";
import FoodListingsNew from "@/pages/food-listings-new";
import FoodListingDetail from "@/pages/food-listing-detail";
import Requests from "@/pages/requests";
import Users from "@/pages/users";
import UsersNew from "@/pages/users-new";
import UserDetail from "@/pages/user-detail";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/food-listings" component={FoodListings} />
        <Route path="/food-listings/new" component={FoodListingsNew} />
        <Route path="/food-listings/:id" component={FoodListingDetail} />
        <Route path="/requests" component={Requests} />
        <Route path="/users" component={Users} />
        <Route path="/users/new" component={UsersNew} />
        <Route path="/users/:id" component={UserDetail} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;