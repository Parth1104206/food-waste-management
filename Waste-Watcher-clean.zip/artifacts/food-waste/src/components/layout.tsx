import { Link, useLocation } from "wouter";
import { LayoutDashboard, Apple, UtensilsCrossed, Users, PlusCircle, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/food-listings", label: "Food Listings", icon: Apple },
    { href: "/requests", label: "Requests", icon: UtensilsCrossed },
    { href: "/users", label: "Community", icon: Users },
  ];

  const SidebarContent = () => (
    <div className="flex h-full flex-col">
      <div className="p-6">
        <Link href="/" className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
            <Apple className="h-6 w-6" />
          </div>
          <span className="text-xl font-serif font-bold tracking-tight text-foreground">
            Bounty
          </span>
        </Link>
      </div>

      <ScrollArea className="flex-1 px-4">
        <nav className="flex flex-col gap-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            
            return (
              <Link key={item.href} href={item.href}>
                <span className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors hover:bg-muted ${
                  isActive ? "bg-primary/10 text-primary" : "text-muted-foreground"
                }`}>
                  <Icon className="h-5 w-5" />
                  {item.label}
                </span>
              </Link>
            );
          })}
        </nav>
      </ScrollArea>
      
      <div className="p-4 mt-auto">
        <div className="rounded-xl bg-accent p-4">
          <h4 className="font-medium text-accent-foreground mb-2">Have surplus?</h4>
          <Link href="/food-listings/new">
            <Button className="w-full justify-start gap-2 shadow-sm">
              <PlusCircle className="h-4 w-4" />
              Post Food
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen w-full bg-background">
      {/* Desktop Sidebar */}
      <aside className="hidden w-64 flex-col border-r bg-card/50 backdrop-blur-xl md:flex fixed inset-y-0 z-50">
        <SidebarContent />
      </aside>

      <div className="flex flex-1 flex-col md:pl-64">
        {/* Mobile Header */}
        <header className="sticky top-0 z-40 flex h-16 items-center gap-4 border-b bg-background/80 px-4 backdrop-blur-xl md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
              <SidebarContent />
            </SheetContent>
          </Sheet>
          <div className="flex items-center gap-2">
            <Apple className="h-5 w-5 text-primary" />
            <span className="font-serif font-bold">Bounty</span>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 p-4 md:p-8">
          <div className="mx-auto max-w-6xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
