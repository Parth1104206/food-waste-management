import { Badge } from "@/components/ui/badge";

export function StatusBadge({ status }: { status: string }) {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  let bgClass = "";
  let textClass = "";

  switch (status.toLowerCase()) {
    case "available":
    case "approved":
      bgClass = "bg-primary/10 hover:bg-primary/20";
      textClass = "text-primary";
      break;
    case "reserved":
    case "pending":
      bgClass = "bg-chart-4/10 hover:bg-chart-4/20";
      textClass = "text-chart-4";
      break;
    case "collected":
      bgClass = "bg-chart-3/10 hover:bg-chart-3/20";
      textClass = "text-chart-3";
      break;
    case "rejected":
    case "expired":
      bgClass = "bg-destructive/10 hover:bg-destructive/20";
      textClass = "text-destructive";
      break;
    default:
      variant = "outline";
  }

  return (
    <Badge variant={variant} className={`${bgClass} ${textClass} border-none font-medium capitalize`}>
      {status}
    </Badge>
  );
}
