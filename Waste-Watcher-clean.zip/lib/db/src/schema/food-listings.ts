import { pgTable, text, serial, timestamp, pgEnum, integer, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const foodStatusEnum = pgEnum("food_status", ["available", "reserved", "collected", "expired"]);

export const foodListingsTable = pgTable("food_listings", {
  id: serial("id").primaryKey(),
  donorId: integer("donor_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  quantity: doublePrecision("quantity").notNull(),
  unit: text("unit").notNull(),
  status: foodStatusEnum("status").notNull().default("available"),
  location: text("location"),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertFoodListingSchema = createInsertSchema(foodListingsTable).omit({ id: true, createdAt: true });
export type InsertFoodListing = z.infer<typeof insertFoodListingSchema>;
export type FoodListing = typeof foodListingsTable.$inferSelect;
