import { pgTable, text, serial, timestamp, pgEnum, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { foodListingsTable } from "./food-listings";

export const requestStatusEnum = pgEnum("request_status", ["pending", "approved", "rejected", "collected"]);

export const donationRequestsTable = pgTable("donation_requests", {
  id: serial("id").primaryKey(),
  listingId: integer("listing_id").notNull().references(() => foodListingsTable.id, { onDelete: "cascade" }),
  requesterId: integer("requester_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  status: requestStatusEnum("status").notNull().default("pending"),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertDonationRequestSchema = createInsertSchema(donationRequestsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertDonationRequest = z.infer<typeof insertDonationRequestSchema>;
export type DonationRequest = typeof donationRequestsTable.$inferSelect;
